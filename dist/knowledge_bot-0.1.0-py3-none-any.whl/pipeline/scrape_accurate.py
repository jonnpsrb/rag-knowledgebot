"""
Scrape Accurate website (https://accurate.id/) with predefined settings
"""
from .web_scraper import WebScraper

def scrape_accurate():
    """
    Scrape Accurate website with optimal settings:
    - URL: https://accurate.id/
    - Max pages: 50
    """
    print("🕷️  Starting Accurate website scraper...")
    print("📊 URL: https://accurate.id/")
    print("📊 Max pages: 50")
    
    scraper = WebScraper(
        base_url="https://accurate.id/",
        max_pages=50
    )
    
    try:
        scraper.crawl()
    except KeyboardInterrupt:
        print("\n⏹️  Crawling interrupted by user")
    except Exception as e:
        print(f"❌ Error during crawling: {e}")

if __name__ == "__main__":
    scrape_accurate()
