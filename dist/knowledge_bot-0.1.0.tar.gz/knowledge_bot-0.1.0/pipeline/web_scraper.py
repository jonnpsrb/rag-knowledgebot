"""
Generic web scraper for any website
This script traverses the website and extracts text content.
"""
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse, urlunparse
import time
import sys
import json
import os
from typing import Set, List

class WebScraper:
    def __init__(self, base_url: str, max_pages: int = 50):
        self.base_url = base_url
        self.max_pages = max_pages
        self.domain = urlparse(base_url).netloc
        self.visited_urls: Set[str] = set()
        self.to_visit: List[str] = [base_url]
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
        
        # Create output directory
        self.output_dir = os.path.join(os.path.dirname(__file__), "files", "webcontent")
        os.makedirs(self.output_dir, exist_ok=True)
        self.page_counter = 0
    
    def is_valid_url(self, url: str) -> bool:
        """Check if URL is within the same domain and not a file/image"""
        parsed = urlparse(url)
        
        # Must be from the same domain
        if parsed.netloc != self.domain:
            return False
            
        # Skip files and images
        skip_extensions = ['.pdf', '.jpg', '.jpeg', '.png', '.gif', '.svg', '.css', '.js', '.ico']
        if any(url.lower().endswith(ext) for ext in skip_extensions):
            return False
            
        # Skip common non-content paths
        skip_paths = ['/wp-admin/', '/wp-content/', '/wp-includes/', '/feed/', '/rss/']
        if any(skip_path in url.lower() for skip_path in skip_paths):
            return False
            
        return True
    
    def clean_url(self, url: str) -> str:
        """Remove query parameters and fragments from URL"""
        parsed = urlparse(url)
        # Rebuild URL without query and fragment
        clean_url = urlunparse((
            parsed.scheme,
            parsed.netloc,
            parsed.path,
            "",  # params
            "",  # query
            ""   # fragment
        ))
        return clean_url
    
    def clean_excessive_whitespace(self, text: str) -> str:
        """Remove excessive whitespace and normalize spacing"""
        import re
        
        # Replace multiple spaces with single space
        text = re.sub(r' +', ' ', text)
        
        # Replace multiple newlines with single newline
        text = re.sub(r'\n+', '\n', text)
        
        # Replace combinations of spaces and newlines
        text = re.sub(r'[ \t]*\n[ \t]*', '\n', text)
        
        # Replace multiple tabs/spaces with single space
        text = re.sub(r'[\t ]+', ' ', text)
        
        # Clean up paragraph breaks (max 2 consecutive newlines)
        text = re.sub(r'\n{3,}', '\n\n', text)
        
        return text.strip()
    
    def extract_links(self, soup: BeautifulSoup, current_url: str) -> List[str]:
        """Extract all valid links from the page"""
        links = []
        for link in soup.find_all('a', href=True):
            href = link['href']
            full_url = urljoin(current_url, href)
            clean_url = self.clean_url(full_url)
            
            if self.is_valid_url(clean_url) and clean_url not in self.visited_urls:
                links.append(clean_url)
        
        return links
    
    def extract_text_content(self, soup: BeautifulSoup) -> str:
        """Extract meaningful text content from the page"""
        # Remove script and style elements
        for script in soup(["script", "style", "nav", "footer", "header"]):
            script.decompose()
        
        # Try to find main content areas
        main_content = soup.find('main') or soup.find('article') or soup.find('div', class_='content')
        
        if main_content:
            text = main_content.get_text()
        else:
            # Fallback to body content
            body = soup.find('body')
            text = body.get_text() if body else soup.get_text()
        
        # Clean up the text
        lines = (line.strip() for line in text.splitlines())
        chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
        text = ' '.join(chunk for chunk in chunks if chunk)
        
        # Additional cleaning for excessive whitespace
        text = self.clean_excessive_whitespace(text)
        
        return text
    
    def save_to_json(self, url: str, content: str):
        """Save content to JSON file"""
        self.page_counter += 1
        filename = f"{self.page_counter}.json"
        filepath = os.path.join(self.output_dir, filename)
        
        data = {
            "url": url,
            "content": content
        }
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        print(f"💾 Saved: {filename}")
    
    def scrape_page(self, url: str) -> tuple[str, List[str]]:
        """Scrape a single page and return text content and links"""
        try:
            print(f"📄 Scraping: {url}")
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Extract text content
            text_content = self.extract_text_content(soup)
            
            # Extract links for further crawling
            links = self.extract_links(soup, url)
            
            return text_content, links
            
        except requests.RequestException as e:
            print(f"❌ Error scraping {url}: {e}")
            return "", []
        except Exception as e:
            print(f"❌ Unexpected error scraping {url}: {e}")
            return "", []
    
    def crawl(self):
        """Main crawling method"""
        print(f"🕷️  Starting crawl of {self.base_url}")
        print(f"📊 Max pages: {self.max_pages}")
        print("=" * 60)
        
        page_count = 0
        
        while self.to_visit and page_count < self.max_pages:
            url = self.to_visit.pop(0)
            clean_url = self.clean_url(url)
            
            if clean_url in self.visited_urls:
                continue
                
            self.visited_urls.add(clean_url)
            page_count += 1
            
            # Scrape the page
            text_content, new_links = self.scrape_page(clean_url)
            
            if text_content:
                print(f"\n🔍 URL: {clean_url}")
                print(f"📝 Text Length: {len(text_content)} characters")
                
                # Save to JSON file
                self.save_to_json(clean_url, text_content)
                
                print("📄 Content Preview:")
                print("-" * 40)
                # Print first 500 characters as preview
                preview = text_content[:500] + "..." if len(text_content) > 500 else text_content
                print(preview)
                print("-" * 40)
            
            # Add new links to visit queue
            for link in new_links:
                if link not in self.visited_urls and link not in self.to_visit:
                    self.to_visit.append(link)
            
            print(f"🔗 Found {len(new_links)} new links")
            print(f"📊 Progress: {page_count}/{self.max_pages} pages, {len(self.to_visit)} in queue")
            print("=" * 60)
            
            # Be respectful - add delay between requests
            time.sleep(0.2)
        
        print(f"\n✅ Crawling completed!")
        print(f"📊 Total pages scraped: {page_count}")
        print(f"🔗 Total URLs discovered: {len(self.visited_urls)}")

def scrape_webpage():
    """Main function to run the web scraper"""
    base_url = "https://accurate.id/"  # Default URL
    max_pages = 50  # Default
    
    if len(sys.argv) >= 2:
        base_url = sys.argv[1]
    
    if len(sys.argv) < 2:
        print("Using default URL: https://accurate.id/")
        print("Usage: python scrape_webpage.py <URL> [max_pages]")
        print("Example: python scrape_webpage.py https://example.com/ 30")
    
    if len(sys.argv) > 2:
        try:
            max_pages = int(sys.argv[2])
        except ValueError:
            print("Usage: python scrape_webpage.py <URL> [max_pages]")
            sys.exit(1)

    scraper = WebScraper(base_url=base_url, max_pages=max_pages)
    
    try:
        scraper.crawl()
    except KeyboardInterrupt:
        print("\n⏹️  Crawling interrupted by user")
    except Exception as e:
        print(f"❌ Error during crawling: {e}")
        sys.exit(1)
