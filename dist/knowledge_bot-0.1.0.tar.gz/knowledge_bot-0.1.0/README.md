# KnowledgeBot

## Project Overview

This is a knowledge bot system that ingests PDF documents and **Accurate's website** into a Qdrant vector database and provides a RAG (Retrieval-Augmented Generation) chatbot interface through terminal. 

The system is built with two main packages:

- **`pipeline`**: 
  - Ingest and extract texts from PDF files (located under: `pipeline/files/pdf/`) 
  - Ingest https://accurate.id's content (scraped and placed under `pipeline/files/webcontent/` as json files)
  - Chunks the text content, and adds to vector storage
- **`chatbot`**: Provides an interactive RAG-based question-answering interface

## Quick Start

1. Run poetry `poetry install`
2. Place PDF files under `pipeline/files/pdf/`
3. **[OPTIONAL]** Run web scraper `poetry run scrape` (Web Scraping has multiple challenges, it could fail in your local environment)
4. Set required env variables (or change in .env file)
   - `QDRANT_URL`
   - `QDRANT_API_KEY`
   - `GROQ_API_KEY`
5. Run ingestion pipeline `poetry run ingest`
6. Start chatbot `poetry run chatbot`


## Configuration

### Env variables

| Variable                    | Required | Description                                               |
|-----------------------------|----------|-----------------------------------------------------------|
| `QDRANT_URL`                | Yes      | Qdrant vector database URL                                |
| `QDRANT_API_KEY`            | Yes      | Qdrant authentication API key                             |
| `GROQ_API_KEY`              | Yes      | Groq LLM API key for chat functionality                   |
| `QDRANT_COLLECTION`         | No       | Collection name in Qdrant (default: `knowledge_base`)     |
| `EMBEDDING_MODEL`           | No       | HuggingFace embedding model (default: `all-MiniLM-L6-v2`) |
| `VECTOR_SIZE`               | No       | Embedding vector dimensions (default: `384`)              |
| `CHUNK_SIZE`                | No       | Text chunk size for document splitting (default: `400`)   |
| `CHUNK_OVERLAP`             | No       | Overlap between text chunks (default: `100`)              |
| `RETRIEVAL_TOP_K`           | No       | Number of documents to retrieve (default: `5`)            |
| `RETRIEVAL_SCORE_THRESHOLD` | No       | Minimum similarity score for retrieval (default: `0.5`)   |
| `LLM_MODEL_NAME`            | No       | Groq model to use (default: `openai/gpt-oss-120b`)        |
| `BOT_NAME`                  | No       | Chatbot display name (default: `Accurate Assistant`)      |
| `BOT_GREETING_MESSAGE`      | No       | Welcome message (default: `Hey, how can I help you?`)     |

### Prompt file

System prompt for the chatbot (loaded from `bot_prompt.md` file)

## Using different embedding model

Update EMBEDDING_MODEL and VECTOR_SIZE then re-run pipeline: `poetry run ingest`


